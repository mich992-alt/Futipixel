# FutiPixel QA Hotfix — 2026-09-01

Files modified:
- `src/components/PixelCanvas.tsx`
- `src/App.tsx`
- `src/index.css`

Main fixes:
1. Physics/movement converted from frame-dependent values to time-based (`dt`) values for player, defenders and balls. This prevents large speed differences/stuttering when React or the browser drops frames.
2. Division 23 QA calibration: player ~118 logical units/s; CPU players ~105–116 logical units/s. Player keeps only a small control advantage.
3. Normal shot restored to a stable time-based velocity (~560 logical units/s upward), with curved and super shots scaled consistently.
4. Shot cooldown moved from frame counters to seconds so firing cadence does not break under frame-rate changes.
5. Match/HUD React synchronization reduced from every animation frame to ~10Hz, with immediate synchronization for score/state changes. This removes a render loop that was unnecessarily restarting/reacting at gameplay frequency.
6. Stable callbacks passed from App to PixelCanvas instead of new inline callback functions on every App render.
7. iOS long-press hardening expanded to child elements; user selection, touch callout, drag, tap highlight and browser gestures are disabled on controls.
8. Action buttons now capture pointer input and release it safely on up/cancel; long press no longer needs to become a browser interaction.
9. Resume countdown and paused states no longer advance physical gameplay.
10. QA telemetry updated to display time-based units rather than misleading px/frame values.

Verification performed:
- TypeScript syntax transpilation passed for the modified TSX files.
- A full npm build could not be run in the sandbox because external dependency installation did not complete; no node_modules were included in the supplied repository.

The locked LeagueEngine v1.0 and MatchEngine v1.0 rule files were intentionally not rewritten by this hotfix.
